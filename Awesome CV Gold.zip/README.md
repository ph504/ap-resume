
## Preview
You can see [PDF](https://github.com/BaulaHANNA/CV-Awesome-Version-Gold/blob/master/resume.pdf)


### Usage

At a command prompt, run
```bash
$ xelatex {your-cv}.tex
```
This should result in the creation of ``{your-cv}.pdf``


## Contact

If you have any questions, feel free to join me at BaulaHANNA

—
Good luck!


